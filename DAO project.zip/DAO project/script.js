document.addEventListener('DOMContentLoaded', () => {
    const uploadButton = document.getElementById('upload-button');
    const fileInput = document.getElementById('file-input');
    const fileList = document.getElementById('file-list');
    const folderModal = document.getElementById('folderModal');
    const closeModal = document.querySelector('.close');
    const submitFolder = document.getElementById('submit-folder');
    let selectedFiles = [];

    // Open the file dialog when the button is clicked
    uploadButton.addEventListener('click', () => {
        fileInput.click();
    });

    // Display selected files
    fileInput.addEventListener('change', (event) => {
        selectedFiles = Array.from(event.target.files);
        displayFileList(selectedFiles);
        folderModal.style.display = 'flex';
    });

    // Close modal when close button is clicked
    closeModal.addEventListener('click', () => {
        folderModal.style.display = 'none';
    });

    // Close modal when clicking outside the modal
    window.addEventListener('click', (event) => {
        if (event.target === folderModal) {
            folderModal.style.display = 'none';
        }
    });

    // Submit keyword and folder name to organize files
    submitFolder.addEventListener('click', () => {
        const keyword = document.getElementById('keyword').value.trim();
        const folderName = document.getElementById('folder-name').value.trim();

        if (keyword && folderName) {
            organizeFiles(keyword, folderName);
            folderModal.style.display = 'none';
        } else {
            alert('Please enter both a keyword and a folder name.');
        }
    });

    // Function to display selected files
    function displayFileList(files) {
        if (files.length === 0) {
            fileList.innerHTML = '<p>No files selected yet.</p>';
            return;
        }

        const fileItems = files.map(file => `<p>${file.name}</p>`).join('');
        fileList.innerHTML = fileItems;
    }

    // Function to organize files based on keyword and folder name
    function organizeFiles(keyword, folderName) {
        const jszip = new JSZip();

        const filteredFiles = selectedFiles.filter(file =>
            file.name.toLowerCase().includes(keyword.toLowerCase())
        );

        if (filteredFiles.length === 0) {
            alert('No files matched the given keyword.');
            return;
        }

        const folder = jszip.folder(folderName);

        filteredFiles.forEach(file => {
            folder.file(file.name, file);
        });

        jszip.generateAsync({ type: 'blob' }).then(content => {
            const link = document.createElement('a');
            link.href = URL.createObjectURL(content);
            link.download = `${folderName}.zip`;
            link.click();
            URL.revokeObjectURL(link.href);
        });

        alert(`${filteredFiles.length} files have been organized into ${folderName}.zip`);
        selectedFiles = [];
        displayFileList(selectedFiles);
    }
});